package com.fstch.YZEduadmin.models;

public class Enter {
	int enter_id;
	String school_name;
	String school_type;
	String school_badge;
	String school_introduce;
	String school_city;
	String school_province;
	String school_license;
	String applicant_user_name;
	String applicant_user_id;
	String receiver_phone;
	String receiver_mail;
	public int getEnter_id() {
		return enter_id;
	}
	public void setEnter_id(int enter_id) {
		this.enter_id = enter_id;
	}
	public String getSchool_name() {
		return school_name;
	}
	public void setSchool_name(String school_name) {
		this.school_name = school_name;
	}
	public String getSchool_type() {
		return school_type;
	}
	public void setSchool_type(String school_type) {
		this.school_type = school_type;
	}
	public String getSchool_badge() {
		return school_badge;
	}
	public void setSchool_badge(String school_badge) {
		this.school_badge = school_badge;
	}
	public String getSchool_introduce() {
		return school_introduce;
	}
	public void setSchool_introduce(String school_introduce) {
		this.school_introduce = school_introduce;
	}
	public String getSchool_city() {
		return school_city;
	}
	public void setSchool_city(String school_city) {
		this.school_city = school_city;
	}
	public String getSchool_province() {
		return school_province;
	}
	public void setSchool_province(String school_province) {
		this.school_province = school_province;
	}
	public String getSchool_license() {
		return school_license;
	}
	public void setSchool_license(String school_license) {
		this.school_license = school_license;
	}
	public String getApplicant_user_name() {
		return applicant_user_name;
	}
	public void setApplicant_user_name(String applicant_user_name) {
		this.applicant_user_name = applicant_user_name;
	}
	public String getApplicant_user_id() {
		return applicant_user_id;
	}
	public void setApplicant_user_id(String applicant_user_id) {
		this.applicant_user_id = applicant_user_id;
	}
	public String getReceiver_phone() {
		return receiver_phone;
	}
	public void setReceiver_phone(String receiver_phone) {
		this.receiver_phone = receiver_phone;
	}
	public String getReceiver_mail() {
		return receiver_mail;
	}
	public void setReceiver_mail(String receiver_mail) {
		this.receiver_mail = receiver_mail;
	}
	
}
