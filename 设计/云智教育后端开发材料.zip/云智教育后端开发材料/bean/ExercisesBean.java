package com.fstech.yzedu.bean;

/**
 * Created by shaoxin on 2018-05-20.
 * 综合练习的模型类
 */

public class ExercisesBean {
	
	private int lesson_id;
	private String course_name;	// 通过id找lesson_title
	private int exercises_state;
	
}
